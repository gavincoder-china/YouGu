<template>
    <div>shshshs</div>
</template>

<script>
    export default {
        name: "test"
    }
</script>

<style scoped>

</style>