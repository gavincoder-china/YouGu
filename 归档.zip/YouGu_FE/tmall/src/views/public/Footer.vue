<template>
    <div class="footer">
        <div class="top">
            <div class="wrapper">
                <div class="clearfix">
                    <a href="#2" class="fl"><img src="../../static/img/foot1.png"/></a>
                    <span class="fl">7天无理由退货</span>
                </div>
                <div class="clearfix">
                    <a href="#2" class="fl"><img src="../../static/img/foot2.png"/></a>
                    <span class="fl">15天免费换货</span>
                </div>
                <div class="clearfix">
                    <a href="#2" class="fl"><img src="../../static/img/foot3.png"/></a>
                    <span class="fl">满599包邮</span>
                </div>
                <div class="clearfix">
                    <a href="#2" class="fl"><img src="../../static/img/foot4.png"/></a>
                    <span class="fl">手机特色服务</span>
                </div>
            </div>
        </div>
        <p class="dibu">芊寻&copy;2019-2027公司版权所有 苏ICP备******-**备0000111000号<br />
            违法和不良信息举报电话：18556815403</p>
    </div>
</template>

<script>
    export default {
        name: "Footer"
    }
</script>

<style scoped>
.footer{

    /*position: fixed;*/
    width: 100%;
    bottom: 0;
}
</style>