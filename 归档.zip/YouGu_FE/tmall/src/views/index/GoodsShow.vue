<template>
    <div>

        <!------------------------------news------------------------------>
        <div class="news">
            <div class="wrapper">
                <h2><img src="../../static/img/ih1.jpg"/></h2>
                <div class="top clearfix">
                    <router-link :to="{path:'/datail'}"><img src="../../static/img/n1.jpg"/><p></p></router-link>
                    <router-link :to="{path:'/datail'}"><img src="../../static/img/n2.jpg"/><p></p></router-link>
                    <router-link :to="{path:'/datail'}"><img src="../../static/img/n3.jpg"/><p></p></router-link>
                </div>
                <div class="bott clearfix">
                    <router-link :to="{path:'/datail'}"><img src="../../static/img/n4.jpg"/><p></p></router-link>
                    <router-link :to="{path:'/datail'}"><img src="../../static/img/n5.jpg"/><p></p></router-link>
                    <router-link :to="{path:'/datail'}"><img src="../../static/img/n6.jpg"/><p></p></router-link>
                </div>
                <h2><img src="../../static/img/ih2.jpg"/></h2>
                <div class="flower clearfix tran">
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/flo1.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【花艺】七头美丽玫瑰仿真花束</dd>
                            <dd><span>¥ 79.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/flo2.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【花艺】七头美丽玫瑰仿真花束</dd>
                            <dd><span>¥ 79.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/flo3.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【花艺】七头美丽玫瑰仿真花束</dd>
                            <dd><span>¥ 79.00</span></dd>
                        </dl>
                    </router-link>
                </div>
                <div class="flower clearfix tran">
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/flo4.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【花艺】七头美丽玫瑰仿真花束</dd>
                            <dd><span>¥ 79.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/flo5.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【花艺】七头美丽玫瑰仿真花束</dd>
                            <dd><span>¥ 79.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/flo6.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【花艺】七头美丽玫瑰仿真花束</dd>
                            <dd><span>¥ 79.00</span></dd>
                        </dl>
                    </router-link>
                </div>
            </div>
        </div>

        <!------------------------------ad------------------------------>
        <a href="#" class="ad"><img src="../../static/img/ib1.jpg"/></a>

        <!------------------------------people------------------------------>
        <div class="people">
            <div class="wrapper">
                <h2><img src="../../static/img/ih3.jpg"/></h2>
                <div class="pList clearfix tran">
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s7.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】不锈钢壁饰墙饰软装</dd>
                            <dd><span>￥688.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s10.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】小城动物木板画壁挂北欧</dd>
                            <dd><span>￥188.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s4.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】玄关假山水壁饰背景墙饰挂件创意</dd>
                            <dd><span>￥599.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s9.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】金属树枝壁饰铜鸟装饰品</dd>
                            <dd><span>￥928.00</span></dd>
                        </dl>
                    </router-link>
                </div>
                <div class="pList clearfix tran">
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s6.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】金属壁饰创意背景墙面挂件创意</dd>
                            <dd><span>￥228.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s8.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】小城动物木板画壁挂北欧</dd>
                            <dd><span>￥199.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s12.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】欧式复古挂钟创意餐厅钟表家居挂件</dd>
                            <dd><span>￥666.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s1.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】客厅地中海欧式现代相片墙创意</dd>
                            <dd><span>￥59.80</span></dd>
                        </dl>
                    </router-link>
                </div>
                <div class="pList clearfix tran">
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s5.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】铁艺荷叶壁挂软装背景墙上装饰品</dd>
                            <dd><span>￥800.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s3.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】欧式照片墙 创意组合结婚礼物</dd>
                            <dd><span>￥189.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s2.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】欧式钟表相框墙挂墙创意组合</dd>
                            <dd><span>￥148.00</span></dd>
                        </dl>
                    </router-link>
                    <router-link :to="{path:'/datail'}">
                        <dl>
                            <dt>
                                <span class="abl"></span>
                                <img src="../../static/img/s11.jpg"/>
                                <span class="abr"></span>
                            </dt>
                            <dd>【芊寻】小城动物木板画壁挂北欧</dd>
                            <dd><span>￥188.00</span></dd>
                        </dl>
                    </router-link>
                </div>
            </div>
        </div>






    </div>
</template>

<script>
    export default {
        name: "GoodsShow"
    }
</script>

<style scoped>

</style>