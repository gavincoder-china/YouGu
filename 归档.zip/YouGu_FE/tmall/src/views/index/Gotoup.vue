<template>
    <div class="gotop">
        <a href="cart.html">
            <dl>
                <dt><img src="../../static/img/gt1.png"/></dt>
                <dd>去购<br />物车</dd>
            </dl>
        </a>
        <a href="#" class="dh">
            <dl>
                <dt><img src="../../static/img/gt2.png"/></dt>
                <dd>联系<br />客服</dd>
            </dl>
        </a>
        <a href="mygrxx.html">
            <dl>
                <dt><img src="../../static/img/gt3.png"/></dt>
                <dd>个人<br />中心</dd>
            </dl>
        </a>
        <a href="#" class="toptop" style="display: none">
            <dl>
                <dt><img src="../../static/img/gt4.png"/></dt>
                <dd>返回<br />顶部</dd>
            </dl>
        </a>
        <p>159-5051-9615</p>
    </div>
</template>

<script>
    export default {
        name: "Gotoup"
    }
</script>

<style scoped>

</style>