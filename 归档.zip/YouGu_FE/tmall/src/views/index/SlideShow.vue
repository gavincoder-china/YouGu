<template>
    <div>
    <div class="block_home_slider">
        <div id="home_slider" class="flexslider">
            <ul class="slides">
                <li>
                    <div class="slide">
                        <img src="../../static/img/banner2.jpg"/>
                    </div>
                </li>
                <li>
                    <div class="slide">
                        <img src="../../static/img/banner1.jpg"/>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="thImg">
        <div class="clearfix">
            <a href="proList.html"><img src="../../static/img/i1.jpg"/></a>
            <a href="proList.html"><img src="../../static/img/i2.jpg"/></a>
            <a href="#2"><img src="../../static/img/i3.jpg"/></a>
        </div>
    </div></div>
</template>

<script>
    export default {
        name: "SlideShow"
    }
</script>

<style scoped>

</style>