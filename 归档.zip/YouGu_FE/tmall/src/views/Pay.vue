<template>

</template>

<script>
    export default {
        name: "Pay"
    }
</script>

<style scoped>
    /*这个是支付完成页*/

</style>