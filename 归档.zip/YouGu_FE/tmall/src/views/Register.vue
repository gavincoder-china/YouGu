<template>
    
</template>

<script>
    export default {
        name: "Register"
    }
</script>

<style scoped>
/*这个是注册页*/
</style>