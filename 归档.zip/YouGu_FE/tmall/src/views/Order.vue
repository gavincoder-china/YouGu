<template>
    
</template>

<script>
    export default {
        name: "Order"
    }
</script>

<style scoped>


    /*这个是订单确认页*/
</style>