<template>

<div>

    <div class="banner">
        <a href="#"><img src="../static/img/temp/banner2.jpg"/></a>
    </div>

    <div class="paintCon">
        <section class="wrapper">
            <h3><img src="../static/img/temp/tit01.jpg"></h3>
            <img src="../static/img/temp/paint01.jpg"/>
        </section>
    </div>




</div>



</template>

<script>
    export default {
        name: "Index02"
    }
</script>

<style scoped>
/*这个是商品推荐页*/


</style>