<template>
    
</template>

<script>
    export default {
        name: "Login"
    }
</script>

<style scoped>
/*这个是登录页*/
</style>