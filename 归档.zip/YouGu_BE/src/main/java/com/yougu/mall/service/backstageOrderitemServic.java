package com.yougu.mall.service;

import com.yougu.mall.entity.Orderitem;

import java.util.List;

public interface backstageOrderitemServic {

    List<Orderitem> queryByAll();
}
