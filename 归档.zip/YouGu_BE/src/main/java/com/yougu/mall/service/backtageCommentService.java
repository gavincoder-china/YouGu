package com.yougu.mall.service;

import com.yougu.mall.entity.Comment;

import java.util.List;

public interface backtageCommentService {

    List<Comment> queryByAll();
}
