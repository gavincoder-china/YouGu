package com.yougu.mall.service;

import com.yougu.mall.entity.Order;


public interface OrderService {

    int insertSelective(Order record);

}
