package com.yougu.mall.service;

import com.yougu.mall.entity.Product;

public interface ProductService {

    Product selectByPrimaryKey(Integer id);

}
