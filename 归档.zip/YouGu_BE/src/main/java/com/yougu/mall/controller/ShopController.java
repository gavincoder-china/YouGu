package com.yougu.mall.controller;

import com.yougu.mall.entity.Cart;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * **********************************************************
 *
 * @Project:
 * @Author : Gavincoder
 * @Mail : xunyegege@gmail.com
 * @Github : https://github.com/xunyegege
 * @ver : version 1.0
 * @Date : 2019-09-10 15:06
 * @description:
 ************************************************************/
@RestController
@RequestMapping("shop")
public class ShopController {






}
